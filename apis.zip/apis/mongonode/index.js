const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// Crear una aplicación Express
const app = express();

// Middleware para parsear el cuerpo de las solicitudes en formato JSON
app.use(bodyParser.json());

// Conexión a MongoDB
mongoose.connect('mongodb+srv://fabian:123456789+@cluster0.guxdn.mongodb.net/Dfashion?retryWrites=true&w=majority&appName=Cluster0', {
    useUnifiedTopology: true
})
.then(() => console.log("Conexión a MongoDB establecida"))
.catch((err) => console.error("Error conectándose a MongoDB:", err));

// Definir el esquema para los datos de pago
const pagoSchema = new mongoose.Schema({
    MetodoPago: { type: String, required: true },
    NumeroTarjeta: { type: String, required: true },
    Correo: { type: String, required: true },
    CodigoSeguridad: { type: String, required: true },
    Identificacion: { type: String, required: true },
    NombreCompleto: { type: String, required: true },
    Telefono: { type: String, required: true },
    Direccion: { type: String, required: true },
    CodigoLealtad: { type: String },
    Total: { type: String, required: true },
    FechaPago: { type: Date, required: true }
});

// Crear un modelo basado en el esquema, especificando el nombre de la colección
const Pago = mongoose.model('Pago', pagoSchema, 'Pagos');

// Ruta POST para crear un pago
app.post('/api/pagos', async (req, res) => {
    try {
        // Crear una nueva instancia del modelo con los datos del cuerpo de la solicitud
        const nuevoPago = new Pago(req.body);

        // Guardar el nuevo pago en la base de datos
        await nuevoPago.save();

        // Enviar una respuesta exitosa con el objeto creado
        res.status(201).json(nuevoPago);
    } catch (error) {
        // Manejar errores y enviar una respuesta de error
        res.status(400).json({ error: error.message });
    }
});

// Iniciar el servidor en el puerto 3000
const port = 3000;
app.listen(port, () => {
    console.log(`Servidor funcionando en el puerto ${port}`);
});
